import { useEffect, useMemo, useState } from "react";

const RECONCILIATION_PAGE_SIZE = 10;

const formatINR = (amount) =>
  new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    maximumFractionDigits: 0,
  }).format(Number(amount) || 0);

const toKey = (item) => `${item.sourceType}:${item.sourceId}`;

const buildBankOptionLabel = (entry) => {
  const amount = Number(entry.amount || entry.credit || entry.debit || 0);
  const reference = entry.reference_no ? ` | ${entry.reference_no}` : "";
  return `${entry.bank_name || "Bank"}${reference} | ${formatINR(amount)}`;
};

const ReconciliationOverview = ({
  summary,
  items,
  bankLedger,
  sourceFilter,
  onSourceFilterChange,
  matchFilter,
  onMatchFilterChange,
  onLink,
  onUnlink,
}) => {
  const [selectedLinks, setSelectedLinks] = useState({});
  const [busyKey, setBusyKey] = useState("");
  const [page, setPage] = useState(1);

  const unlinkedLedger = useMemo(
    () =>
      (bankLedger || []).filter(
        (entry) => !entry.source_type && !entry.source_id && !entry.sourceType && !entry.sourceId,
      ),
    [bankLedger],
  );

  const getCandidates = (item) =>
    unlinkedLedger.filter((entry) => {
      const entryDirection = String(entry.direction || (Number(entry.debit || 0) > 0 ? "out" : "in"))
        .trim()
        .toLowerCase();
      const itemDirection = String(item.direction || "in").trim().toLowerCase();
      if (entryDirection !== itemDirection) return false;

      const entryMode = String(entry.payment_mode || entry.paymentMode || "manual")
        .trim()
        .toLowerCase();
      const itemMode = String(item.paymentMode || "unknown")
        .trim()
        .toLowerCase();
      return entryMode === "manual" || entryMode === itemMode;
    });

  const totalPages = Math.max(1, Math.ceil((items || []).length / RECONCILIATION_PAGE_SIZE));
  const paginatedItems = (items || []).slice(
    (page - 1) * RECONCILIATION_PAGE_SIZE,
    page * RECONCILIATION_PAGE_SIZE,
  );

  useEffect(() => {
    setPage(1);
  }, [sourceFilter, matchFilter, items]);

  useEffect(() => {
    if (page > totalPages) {
      setPage(totalPages);
    }
  }, [page, totalPages]);

  const handleLink = async (item) => {
    const key = toKey(item);
    const bankLedgerId = selectedLinks[key];
    if (!bankLedgerId) return;

    setBusyKey(key);
    try {
      await onLink({
        bankLedgerId,
        sourceType: item.sourceType,
        sourceId: item.sourceId,
        matchedAmount: item.sourceAmount,
      });
      setSelectedLinks((prev) => ({ ...prev, [key]: "" }));
    } finally {
      setBusyKey("");
    }
  };

  const handleUnlink = async (item) => {
    if (!item.linkedBankLedgerId) return;
    setBusyKey(toKey(item));
    try {
      await onUnlink({ bankLedgerId: item.linkedBankLedgerId });
    } finally {
      setBusyKey("");
    }
  };

  return (
    <section className="rounded-[26px] border border-white/60 bg-white/82 p-5 shadow-[0_18px_45px_rgba(15,23,42,0.08)]">
      <div className="flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
        <div>
          <div className="text-[18px] font-semibold uppercase tracking-[0.18em] text-cyan-800">
            Linked Reconciliation Flow
          </div>
          <h2 className="mt-2 text-[2.6rem] font-black text-slate-950">
            Billing to bank reconciliation view
          </h2>
          <p className="mt-3 max-w-3xl text-[20px] font-semibold leading-8 text-slate-800">
            Match paid hotel invoices, restaurant bills, banquet invoices, and vendor payouts with
            bank ledger rows so the accounts team can verify what is billed, what reached the bank,
            and what still needs action.
          </p>
        </div>

        <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
          {[
            { label: "Bank In", value: formatINR(summary.totalBankIn), tone: "text-cyan-700" },
            { label: "Bank Out", value: formatINR(summary.totalBankOut), tone: "text-rose-700" },
            { label: "Unmatched Amount", value: formatINR(summary.unmatchedAmount), tone: "text-amber-700" },
            { label: "Reconciled Amount", value: formatINR(summary.reconciledAmount), tone: "text-emerald-700" },
          ].map((card) => (
            <div
              key={card.label}
              className="min-w-[180px] rounded-[20px] border border-slate-200 bg-slate-50 px-5 py-4"
            >
              <div className="text-[16px] font-semibold uppercase tracking-[0.16em] text-slate-700">
                {card.label}
              </div>
              <div className={`mt-3 text-[2.2rem] font-black ${card.tone}`}>{card.value}</div>
            </div>
          ))}
        </div>
      </div>

      <div className="mt-5 grid gap-3 md:grid-cols-2 xl:grid-cols-3">
        <label className="block">
          <span className="mb-2 block text-[16px] font-semibold uppercase tracking-[0.14em] text-slate-700">
            Source Filter
          </span>
          <select
            value={sourceFilter}
            onChange={(event) => onSourceFilterChange(event.target.value)}
            className="w-full rounded-xl border border-slate-200 bg-white px-4 py-3 text-[18px] font-semibold text-slate-950 outline-none"
          >
            <option value="all">All Sources</option>
            <option value="invoice">Hotel Invoices</option>
            <option value="restaurant_bill">Restaurant Bills</option>
            <option value="banquet">Banquet Invoices</option>
            <option value="vendor_payment">Vendor Payments</option>
          </select>
        </label>

        <label className="block">
          <span className="mb-2 block text-[16px] font-semibold uppercase tracking-[0.14em] text-slate-700">
            Match Filter
          </span>
          <select
            value={matchFilter}
            onChange={(event) => onMatchFilterChange(event.target.value)}
            className="w-full rounded-xl border border-slate-200 bg-white px-4 py-3 text-[18px] font-semibold text-slate-950 outline-none"
          >
            <option value="all">All Match States</option>
            <option value="unmatched">Unmatched</option>
            <option value="partial">Partial</option>
            <option value="matched">Matched</option>
            <option value="reconciled">Reconciled</option>
          </select>
        </label>

        <div className="rounded-[18px] border border-slate-200 bg-slate-50 px-5 py-4 text-[18px] font-semibold text-slate-800">
          <div className="text-[16px] font-semibold uppercase tracking-[0.16em] text-slate-700">
            Flow Hint
          </div>
          <div className="mt-2 leading-7">
            Paid billing rows should be linked with a bank ledger entry. Cash rows can remain
            outside bank reconciliation.
          </div>
        </div>
      </div>

      <div className="mt-5 overflow-x-auto rounded-[18px] border border-slate-200">
        <table className="min-w-full text-left text-[16px]">
          <thead className="bg-slate-50 text-[16px] font-semibold uppercase tracking-[0.14em] text-slate-700">
            <tr>
              <th className="px-3 py-4">Source</th>
              <th className="px-3 py-4">Reference</th>
              <th className="px-3 py-4">Party</th>
              <th className="px-3 py-4">Label</th>
              <th className="px-3 py-4">Payment Mode</th>
              <th className="px-3 py-4">Billed</th>
              <th className="px-3 py-4">Bank</th>
              <th className="px-3 py-4">Difference</th>
              <th className="px-3 py-4">Match</th>
              <th className="px-3 py-4">Reconciliation</th>
              <th className="px-3 py-4">Action</th>
            </tr>
          </thead>
          <tbody>
            {paginatedItems.map((item) => {
              const key = toKey(item);
              const candidates = getCandidates(item);
              const busy = busyKey === key;

              return (
                <tr key={key} className="border-t border-slate-200">
                  <td className="px-3 py-4 text-[16px] font-semibold text-slate-800">{item.sourceType}</td>
                  <td className="px-3 py-4 text-[18px] font-semibold text-slate-950">{item.sourceReference}</td>
                  <td className="px-3 py-4 text-[16px] font-semibold text-slate-800">{item.partyName || "-"}</td>
                  <td className="px-3 py-4 text-[16px] font-semibold text-slate-800">{item.sourceLabel || "-"}</td>
                  <td className="px-3 py-4 text-[16px] font-semibold text-slate-800">{item.paymentMode || "-"}</td>
                  <td className="px-3 py-4 text-[18px] font-semibold text-slate-950">
                    {formatINR(item.sourceAmount)}
                  </td>
                  <td className="px-3 py-4 text-[16px] font-semibold text-slate-800">{formatINR(item.bankAmount)}</td>
                  <td className="px-3 py-4 text-[16px] font-semibold text-slate-800">{formatINR(item.difference)}</td>
                  <td className="px-3 py-4">
                    <span className="rounded-full border border-slate-200 bg-slate-50 px-3.5 py-1.5 text-[15px] font-semibold text-slate-800">
                      {item.matchStatus}
                    </span>
                  </td>
                  <td className="px-3 py-4">
                    <span className="rounded-full border border-slate-200 bg-slate-50 px-3.5 py-1.5 text-[15px] font-semibold text-slate-800">
                      {item.reconciliationStatus}
                    </span>
                  </td>
                  <td className="px-3 py-4">
                    {item.linkedBankLedgerId ? (
                      <button
                        type="button"
                        disabled={busy}
                        onClick={() => handleUnlink(item)}
                        className="rounded-full border border-rose-200 bg-rose-50 px-4 py-2 text-[15px] font-semibold text-rose-700 disabled:opacity-60"
                      >
                        Unlink
                      </button>
                    ) : candidates.length ? (
                      <div className="flex min-w-[240px] flex-col gap-2">
                        <select
                          value={selectedLinks[key] || ""}
                          onChange={(event) =>
                            setSelectedLinks((prev) => ({ ...prev, [key]: event.target.value }))
                          }
                          className="rounded-xl border border-slate-200 bg-white px-3 py-2.5 text-[15px] font-semibold text-slate-950 outline-none"
                        >
                          <option value="">Select bank row</option>
                          {candidates.map((entry) => (
                            <option key={entry.id} value={entry.id}>
                              {buildBankOptionLabel(entry)}
                            </option>
                          ))}
                        </select>
                        <button
                          type="button"
                          disabled={busy || !selectedLinks[key]}
                          onClick={() => handleLink(item)}
                          className="rounded-full border border-cyan-200 bg-cyan-50 px-4 py-2 text-[15px] font-semibold text-cyan-700 disabled:opacity-60"
                        >
                          Link
                        </button>
                      </div>
                    ) : (
                      <span className="text-[15px] font-semibold text-slate-700">No free bank row</span>
                    )}
                  </td>
                </tr>
              );
            })}
            {!items?.length ? (
              <tr>
                <td colSpan={11} className="px-3 py-8 text-center text-[18px] font-semibold text-slate-700">
                  No reconciliation items for the selected filters.
                </td>
              </tr>
            ) : null}
          </tbody>
        </table>
      </div>

      {(items || []).length > RECONCILIATION_PAGE_SIZE ? (
        <div className="mt-4 flex flex-col gap-3 rounded-[18px] border border-slate-200 bg-white px-4 py-4 sm:flex-row sm:items-center sm:justify-between">
          <div className="text-base text-slate-500">
            Showing{" "}
            <span className="font-semibold text-slate-900">
              {(page - 1) * RECONCILIATION_PAGE_SIZE + 1}
            </span>{" "}
            to{" "}
            <span className="font-semibold text-slate-900">
              {Math.min(page * RECONCILIATION_PAGE_SIZE, (items || []).length)}
            </span>{" "}
            of{" "}
            <span className="font-semibold text-slate-900">{(items || []).length}</span>{" "}
            reconciliation rows
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={() => setPage((current) => Math.max(1, current - 1))}
              disabled={page === 1}
              className="rounded-full border border-slate-200 bg-white px-4 py-2.5 text-sm font-semibold text-slate-600 transition hover:bg-slate-50 disabled:cursor-not-allowed disabled:opacity-50"
            >
              Previous
            </button>

            {Array.from({ length: totalPages }, (_, index) => {
              const pageNumber = index + 1;
              const isActive = pageNumber === page;

              return (
                <button
                  key={`reconciliation-page-${pageNumber}`}
                  type="button"
                  onClick={() => setPage(pageNumber)}
                  className={`h-10 min-w-[40px] rounded-full border px-3 text-sm font-bold transition ${
                    isActive
                      ? "border-cyan-600 bg-cyan-600 text-white shadow-[0_10px_24px_rgba(8,145,178,0.18)]"
                      : "border-slate-200 bg-white text-slate-600 hover:bg-slate-50"
                  }`}
                >
                  {pageNumber}
                </button>
              );
            })}

            <button
              type="button"
              onClick={() => setPage((current) => Math.min(totalPages, current + 1))}
              disabled={page === totalPages}
              className="rounded-full border border-slate-200 bg-white px-4 py-2.5 text-sm font-semibold text-slate-600 transition hover:bg-slate-50 disabled:cursor-not-allowed disabled:opacity-50"
            >
              Next
            </button>
          </div>
        </div>
      ) : null}
    </section>
  );
};

export default ReconciliationOverview;
